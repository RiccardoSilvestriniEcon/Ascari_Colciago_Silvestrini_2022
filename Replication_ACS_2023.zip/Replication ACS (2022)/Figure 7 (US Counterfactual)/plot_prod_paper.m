load all_results
load Cyc_labor_prod


for i=1:4
   
    Z(i,1)=100*(Ztilde(i*10)-Ztildebar)/Ztildebar;
    
end

startDate = datenum('01-04-2020');
endDate = datenum('01-01-2021');
xData = linspace(startDate,endDate,4);


figure(1)

subplot(1,2,2)
plot(100*(Ztilde(6:42)-Ztildebar)/Ztildebar,'b-','LineWidth',2);
xticks([0 13 26 40]);
xticklabels({'Q2-20', 'Q3-20', 'Q4-20', 'Q1-21'});
title('Aggregate Productivity Model');
subplot(1,2,1)
plot(xData,100*Cyc_labor_prod(294:297),'b-','LineWidth',2)
ax = gca; 
ax.XTick = xData(1:1:4);
datetick('x','QQ-YY','Keepticks')
xticks
xlim([startDate endDate]);
xticklabels({'Q2-20', 'Q3-20', 'Q4-20', 'Q1-21'});
title('Aggregate Productivity Data');

savefig fig7.fig
