%%%%%%%%%%%% ACS (2023). How to replicate US counterfactual (and figure 7)

%%%%%%%%%%%% 1) Run SS_benchmark to store steady state (output: SS_for_dynare).

%%%%%%%%%%%% 2) Run acs_benchmark_US on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_results, and functions go_calibrate and calibrate_pi) 
%%%%%%%%%%%% to store results and simulate response (output: all_results).

%%%%%%%%%%%% 4) Run plot_prod_paper (input, HP filtered series for labor 
%%%%%%%%%%%% productivity from folder "Figure 4 (Productivity)"
%%%%%%%%%%%% Cyc_labor_prod) for decomposition productivity (output:
%%%%%%%%%%%% fig7.fig) --> Figure7.fig and Figure7.png.

%%%%%%%%%%%% Run plot_model or plot_decomposition for full simulation
%%%%%%%%%%%% and decomposition of productivity.