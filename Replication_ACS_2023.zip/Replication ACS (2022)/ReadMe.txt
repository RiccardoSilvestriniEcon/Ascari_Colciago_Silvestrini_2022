Replication package Ascari, Colciago and Silvestrini (2023):

BLS and BDS: Excel files --> raw data and results for firm exit and sectoral productivity used in the main text.

Figures 1 to 15: MATLAB files --> model simulations and raw data (and figures) for all the results presented in the main text and appendix.

Each folder contains ReadMe files where the specific routines are described more in depth.