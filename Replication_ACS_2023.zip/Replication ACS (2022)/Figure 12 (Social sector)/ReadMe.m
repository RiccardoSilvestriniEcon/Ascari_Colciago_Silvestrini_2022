%%%%%%%%%%%% How to replicate paper Figure 12:

%%%%%%%%%%%% 1) Run SS_025/075 to store steady states of the two different
%%%%%%%%%%%% economies. Output --> SS_for_dynare_025/075

%%%%%%%%%%%% 2) Run acs_..._025/075 on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result/_L, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results for models with different size of social sector -->
%%%%%%%%%%%% output all_results (chi=0.34, US) and all_results_L (chi=.66)

%%%%%%%%%%%% 3) Run plot_paper for figure 12 in the paper, output:
%%%%%%%%%%%% fig12.fig --> Figure12.fig and Figure12.png.

%%%%%%%%%%%% Run plot_simulation for comparison simulations.
