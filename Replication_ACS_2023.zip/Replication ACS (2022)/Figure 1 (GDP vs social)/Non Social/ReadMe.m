%%%%%%%% Series for GDP US and non-Social sectors, BEA data (available at
%%%%%%%% https://www.bea.gov/data/gdp/gdp-industry).