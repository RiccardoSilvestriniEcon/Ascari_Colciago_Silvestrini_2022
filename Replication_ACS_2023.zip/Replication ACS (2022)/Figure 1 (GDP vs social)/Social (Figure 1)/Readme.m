%%%%%%% series for GDP US and social sectors from BEA (available at 
%%%%%%% https://www.bea.gov/data/gdp/gdp-industry)

%%%%%% hpfilter routine (Folder Figure 4) MATLAB Econometric toolbox are
%%%%%% required.

%%%%%%% gdp_total_social groups the GDP of the social sectors together

%%%%%%%%%%% plot_GDP.m: uses raw BEA data as inputs to plot the cyclical
%%%%%%%%%%% component of GDP and contrast it to the one of the social
%%%%%%%%%%% sectors only --> output: Figure1.fig and Figure1.png