clear all
close all
clc

load gdp_retail_trade
load gdp_real_esta
load gdp_health_soc
load gdp_edu_serv
load gdp_construction
load gdp_art_enta
load gdp_accommodation
load gdp_US
load gdp_total_social



[gdp_us_t,gdp_us_c] = hpfilter(log(gdp_US),1600); %entry 61 is 1 quarter 2019

[gdp_accom_t,gdp_accom_c] = hpfilter(log(gdp_accommodation),1600);

[gdp_retail_t,gdp_retail_c] = hpfilter(log(gdp_retail_trade),1600);

[gdp_esta_t,gdp_esta_c] = hpfilter(log(gdp_real_esta),1600);

[gdp_health_t,gdp_health_c] = hpfilter(log(gdp_health_soc),1600);

[gdp_edu_t,gdp_edu_c] = hpfilter(log(gdp_edu_serv),1600);

[gdp_construction_t,gdp_construction_c] = hpfilter(log(gdp_construction),1600);

[gdp_art_enta_t,gdp_art_enta_c] = hpfilter(log(gdp_art_enta),1600);

[gdp_social_t,gdp_social_c] = hpfilter(log(gdp_total_social),1600); %entry 61 is 1 quarter 2019


periodi=length(gdp_art_enta_c);

%entry 57 is the first quarter of 2019

time=(57:1:periodi);

startDate = datenum('01-01-19');
endDate = datenum('10-01-21');
xData = linspace(startDate,endDate,11);

figure(1)

subplot(4,2,1)
plot(xData,gdp_accom_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(i) Accomodation and Food')

subplot(4,2,2)
plot(xData,gdp_art_enta_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(ii) Arts and Entartainment')


subplot(4,2,3)
plot(xData,gdp_edu_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(iii) Educational services')



subplot(4,2,4)
plot(xData,gdp_health_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(iv) Health and Social services ')


subplot(4,2,5)
plot(xData,gdp_esta_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(v) Real Estate')

subplot(4,2,6)
plot(xData,gdp_construction_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(vi) Construction')

subplot(4,2,7)
plot(xData,gdp_retail_c(57:periodi)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(vii) Retail Trade')

figure(2)

plot(xData,gdp_us_c(61:(end-1))*100,'b','LineWidth',1)
hold on
plot(xData,gdp_social_c(57:periodi)*100,'r','LineWidth',1)
ax = gca; 
ax.XTick = xData(1:1:11);
datetick('x','QQ-YY','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('Aggregate GDP Vs GDP of the Social Sector')

