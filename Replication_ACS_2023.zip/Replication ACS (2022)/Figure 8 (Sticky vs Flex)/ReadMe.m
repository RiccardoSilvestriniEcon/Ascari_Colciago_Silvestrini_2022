%%%%%%%%%%%%%%%%% How to replicate paper Figure 8

%%%%%%%%%%%% 1) Run SS_benchmark to store steady state of the economy (same
%%%%%%%%%%%% for both models) --> output SS_for_dynare.

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result, functions go_calibrate and calibrate_pi) to
%%%%%%%%%%%% store results --> output: all_results

%%%%%%%%%%%% 3) Run acs_flex on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result_L, functions go_calibrate and calibrate_pi)
%%%%%%%%%%%% to store results --> output: all_results_L

%%%%%%%%%%%% 4) Run plot_paper to get figure 8 in the paper --> output:
%%%%%%%%%%%% Figure8.fig and Figure8.png.
