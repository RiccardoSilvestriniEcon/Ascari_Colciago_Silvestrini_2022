Folder BLS:

Raw data: download from BLS @ https://www.bls.gov/productivity/, dataset name: Detailed industries labor productivity --> csv file named labor-productivity-detailed-industries.

BLS_labor_prod_trim --> cleaned and trimmed version of labor-productivity-detailed-industries: 2005-2020, yearly % change in labor productivity for NAICS-2 to 6 sectors + sectors type (social vs. non-social) from Kaplan, Moll and Violante. The dataset contains three sheets for robustness: KMV (Manufacturing is a non-social sector), Manu=S (Manufacturing is a social sector) and ACS (Manufacturing is removed).

collapse_prod_... --> STATA dofile. It collapses the change in labor productivity as an average rate per sector type. Three files, one per specification above. Results are exported in estimate_...

estimate1_KMV --> results for Manufacturing as a non-social sector

estimate2_Manu=S --> results for Manufacturing as a social sector

estimate3_ACS --> results without Manufacturing.