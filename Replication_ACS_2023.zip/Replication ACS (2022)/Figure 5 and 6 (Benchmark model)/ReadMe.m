%%%%%%%%%%%% ACS (2023). How to replicate paper Figures 5 and 6

%%%%%%%%%%%% 1) Run SS_benchmark to store steady state (output: SS_for_dynare).

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result, and functions go_calibrate and calibrate_pi) 
%%%%%%%%%%%% to store results and simulate benchmark response (output: all_results).

%%%%%%%%%%%% 3) Run plot_paper for benchmark figure 5 in the paper.
%%%%%%%%%%%% (output: fig5.fig) --> Figure5.fig and Figure5.png.

%%%%%%%%%%%% 4) Run plot_prod_paper (input, HP filtered series for labor 
%%%%%%%%%%%% productivity from folder "Figure 4 (Productivity)"
%%%%%%%%%%%% Cyc_labor_prod) for decomposition productivity (output:
%%%%%%%%%%%% fig6.fig) --> Figure6.png and Figure6.fig.