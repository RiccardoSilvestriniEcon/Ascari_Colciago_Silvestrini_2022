Folder BDS:

Raw data (download from BDS @ https://www.census.gov/data/datasets/time-series/econ/bds/bds-datasets.html, dataset name: Sector by Firm Size --> csv file named bds2020_sec_fz.

bds2020_sec_fz_trim --> from bds2020_sec_fz, dataset trimmed to 2005-2020, establishment entry and exit rate for small firms (fsize 1 to 4).

BDS_exit --> input for STATA dofile, data from bds2020_sec_fz_trim + sector type (social vs. non-social) from Kaplan, Moll and Violante (2020).

exitrate_2020 --> STATA dofile. It collapses BDS_exit in a panel year*sector_type, where each pair presents the average exit rate in that pair. The dofile computes the difference in the exit rate in 2020 with respect to the average up to 2019 and with respect to a linear trend. Results stored in estimate_exit

estimate_exit --> results.