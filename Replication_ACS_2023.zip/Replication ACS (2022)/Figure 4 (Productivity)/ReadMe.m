%%%%%%%%%%%% ACS (2023). How to replicate paper Figure 4

%%%%%%%%%%%% Raw data: us_YoverH_nnfarm.mat from FRED-MD (Non-farm Business Sector
%%%%%%%%%%%% Real Output Per Hour)

%%%%%%%%%%%% Run nonfarm_YoverH (using hpfilter and us_YoverH_nnfarm) to
%%%%%%%%%%%% generate and store empirical path of cyclical labor productivity.
%%%%%%%%%%%% output --> Cyc_labor_prod.mat and fig4.fig (Figure 4 paper).

%%%%%%%%%%% output Figure4.png and Figure4.fig.