%%%%%%%%%%%%%%%%% How to replicate paper Figure 10:

%%%%%%%%%%%% 1) Run SS_benchmark to store steady state of the economy -->
%%%%%%%%%%%% output: SS_for_dynare (same for all models).

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results and simulate model --> output: all_results.mat

%%%%%%%%%%%% 3) Run acs_..._permanent/25/50 on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result_L/2/3, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results for different duration of SD measures --> output:
%%%%%%%%%%%% all_results_L (perma) ..._L2 (6 months) ..._L3 (1 year).

%%%%%%%%%%%% 4) Run plot_paper for figure 10 in the paper --> output:
%%%%%%%%%%%% fig10.fig --> Figure10.png and Figure10.fig.
