clear all;

Y1=load('all_results','Y');
Y1=Y1.('Y');
Ybar1=load('all_results','Ybar');
Ybar1=Ybar1.('Ybar');
Y2=load('all_results_L','Y');
Y2=Y2.('Y');
Ybar2=load('all_results_L','Ybar');
Ybar2=Ybar2.('Ybar');
Y3=load('all_results_L2','Y');
Y3=Y3.('Y');
Ybar3=load('all_results_L2','Ybar');
Ybar3=Ybar3.('Ybar');
Y4=load('all_results_L3','Y');
Y4=Y4.('Y');
Ybar4=load('all_results_L3','Ybar');
Ybar4=Ybar4.('Ybar');

X1=load('all_results','X');
X1=X1.('X');
Xbar1=load('all_results','Xbar');
Xbar1=Xbar1.('Xbar');
X2=load('all_results_L','X');
X2=X2.('X');
Xbar2=load('all_results_L','Xbar');
Xbar2=Xbar2.('Xbar');
X3=load('all_results_L2','X');
X3=X3.('X');
Xbar3=load('all_results_L2','Xbar');
Xbar3=Xbar3.('Xbar');
X4=load('all_results_L3','X');
X4=X4.('X');
Xbar4=load('all_results_L3','Xbar');
Xbar4=Xbar4.('Xbar');

GDP1=load('all_results','GDP');
GDP1=GDP1.('GDP');
GDPbar1=load('all_results','GDPbar');
GDPbar1=GDPbar1.('GDPbar');
GDP2=load('all_results_L','GDP');
GDP2=GDP2.('GDP');
GDPbar2=load('all_results_L','GDPbar');
GDPbar2=GDPbar2.('GDPbar');
GDP3=load('all_results_L2','GDP');
GDP3=GDP3.('GDP');
GDPbar3=load('all_results_L2','GDPbar');
GDPbar3=GDPbar3.('GDPbar');
GDP4=load('all_results_L3','GDP');
GDP4=GDP4.('GDP');
GDPbar4=load('all_results_L3','GDPbar');
GDPbar4=GDPbar4.('GDPbar');

C1=load('all_results','C');
C1=C1.('C');
Cbar1=load('all_results','Cbar');
Cbar1=Cbar1.('Cbar');
C2=load('all_results_L','C');
C2=C2.('C');
Cbar2=load('all_results_L','Cbar');
Cbar2=Cbar2.('Cbar');
C3=load('all_results_L2','C');
C3=C3.('C');
Cbar3=load('all_results_L2','Cbar');
Cbar3=Cbar3.('Cbar');
C4=load('all_results_L3','C');
C4=C4.('C');
Cbar4=load('all_results_L3','Cbar');
Cbar4=Cbar4.('Cbar');

C11=load('all_results','C1');
C11=C11.('C1');
C1bar1=load('all_results','C1bar');
C1bar1=C1bar1.('C1bar');
C12=load('all_results_L','C1');
C12=C12.('C1');
C1bar2=load('all_results_L','C1bar');
C1bar2=C1bar2.('C1bar');
C13=load('all_results_L2','C1');
C13=C13.('C1');
C1bar3=load('all_results_L2','C1bar');
C1bar3=C1bar3.('C1bar');
C14=load('all_results_L3','C1');
C14=C14.('C1');
C1bar4=load('all_results_L3','C1bar');
C1bar4=C1bar4.('C1bar');

C21=load('all_results','C2');
C21=C21.('C2');
C2bar1=load('all_results','C2bar');
C2bar1=C2bar1.('C2bar');
C22=load('all_results_L','C2');
C22=C22.('C2');
C2bar2=load('all_results_L','C2bar');
C2bar2=C2bar2.('C2bar');
C23=load('all_results_L2','C2');
C23=C23.('C2');
C2bar3=load('all_results_L2','C2bar');
C2bar3=C2bar3.('C2bar');
C24=load('all_results_L3','C2');
C24=C24.('C2');
C2bar4=load('all_results_L3','C2bar');
C2bar4=C2bar4.('C2bar');

ls1=load('all_results','ls');
ls1=ls1.('ls');
lsbar1=load('all_results','lsbar');
lsbar1=lsbar1.('lsbar');
ls2=load('all_results_L','ls');
ls2=ls2.('ls');
lsbar2=load('all_results_L','lsbar');
lsbar2=lsbar2.('lsbar');
ls3=load('all_results_L2','ls');
ls3=ls3.('ls');
lsbar3=load('all_results_L2','lsbar');
lsbar3=lsbar3.('lsbar');
ls4=load('all_results_L3','ls');
ls4=ls4.('ls');
lsbar4=load('all_results_L3','lsbar');
lsbar4=lsbar4.('lsbar');

w1=load('all_results','w');
w1=w1.('w');
wbar1=load('all_results','wbar');
wbar1=wbar1.('wbar');
w2=load('all_results_L','w');
w2=w2.('w');
wbar2=load('all_results_L','wbar');
wbar2=wbar2.('wbar');
w3=load('all_results_L2','w');
w3=w3.('w');
wbar3=load('all_results_L2','wbar');
wbar3=wbar3.('wbar');
w4=load('all_results_L3','w');
w4=w4.('w');
wbar4=load('all_results_L3','wbar');
wbar4=wbar4.('wbar');

N11=load('all_results','N1');
N11=N11.('N1');
N1bar1=load('all_results','N1bar');
N1bar1=N1bar1.('N1bar');
N12=load('all_results_L','N1');
N12=N12.('N1');
N1bar2=load('all_results_L','N1bar');
N1bar2=N1bar2.('N1bar');
N13=load('all_results_L2','N1');
N13=N13.('N1');
N1bar3=load('all_results_L2','N1bar');
N1bar3=N1bar3.('N1bar');
N14=load('all_results_L3','N1');
N14=N14.('N1');
N1bar4=load('all_results_L3','N1bar');
N1bar4=N1bar4.('N1bar');

no11=load('all_results','no1');
no11=no11.('no1');
no1bar1=load('all_results','no1bar');
no1bar1=no1bar1.('no1bar');
no12=load('all_results_L','no1');
no12=no12.('no1');
no1bar2=load('all_results_L','no1bar');
no1bar2=no1bar2.('no1bar');
no13=load('all_results_L2','no1');
no13=no13.('no1');
no1bar3=load('all_results_L2','no1bar');
no1bar3=no1bar3.('no1bar');
no14=load('all_results_L3','no1');
no14=no14.('no1');
no1bar4=load('all_results_L3','no1bar');
no1bar4=no1bar4.('no1bar');

N21=load('all_results','N2');
N21=N21.('N2');
N2bar1=load('all_results','N2bar');
N2bar1=N2bar1.('N2bar');
N22=load('all_results_L','N2');
N22=N22.('N2');
N2bar2=load('all_results_L','N2bar');
N2bar2=N2bar2.('N2bar');
N23=load('all_results_L2','N2');
N23=N23.('N2');
N2bar3=load('all_results_L2','N2bar');
N2bar3=N2bar3.('N2bar');
N24=load('all_results_L3','N2');
N24=N24.('N2');
N2bar4=load('all_results_L3','N2bar');
N2bar4=N2bar4.('N2bar');

no21=load('all_results','no2');
no21=no21.('no2');
no2bar1=load('all_results','no2bar');
no2bar1=no2bar1.('no2bar');
no22=load('all_results_L','no2');
no22=no22.('no2');
no2bar2=load('all_results_L','no2bar');
no2bar2=no2bar2.('no2bar');
no23=load('all_results_L2','no2');
no23=no23.('no2');
no2bar3=load('all_results_L2','no2bar');
no2bar3=no2bar3.('no2bar');
no24=load('all_results_L3','no2');
no24=no24.('no2');
no2bar4=load('all_results_L3','no2bar');
no2bar4=no2bar4.('no2bar');

Ne11=load('all_results','Ne1');
Ne11=Ne11.('Ne1');
Ne1bar1=load('all_results','Ne1bar');
Ne1bar1=Ne1bar1.('Ne1bar');
Ne12=load('all_results_L','Ne1');
Ne12=Ne12.('Ne1');
Ne1bar2=load('all_results_L','Ne1bar');
Ne1bar2=Ne1bar2.('Ne1bar');
Ne13=load('all_results_L2','Ne1');
Ne13=Ne13.('Ne1');
Ne1bar3=load('all_results_L2','Ne1bar');
Ne1bar3=Ne1bar3.('Ne1bar');
Ne14=load('all_results_L3','Ne1');
Ne14=Ne14.('Ne1');
Ne1bar4=load('all_results_L3','Ne1bar');
Ne1bar4=Ne1bar4.('Ne1bar');

Ne21=load('all_results','Ne2');
Ne21=Ne21.('Ne2');
Ne2bar1=load('all_results','Ne2bar');
Ne2bar1=Ne2bar1.('Ne2bar');
Ne22=load('all_results_L','Ne2');
Ne22=Ne22.('Ne2');
Ne2bar2=load('all_results_L','Ne2bar');
Ne2bar2=Ne2bar2.('Ne2bar');
Ne23=load('all_results_L2','Ne2');
Ne23=Ne23.('Ne2');
Ne2bar3=load('all_results_L2','Ne2bar');
Ne2bar3=Ne2bar3.('Ne2bar');
Ne24=load('all_results_L3','Ne2');
Ne24=Ne24.('Ne2');
Ne2bar4=load('all_results_L3','Ne2bar');
Ne2bar4=Ne2bar4.('Ne2bar');

zc11=load('all_results','zc1');
zc11=zc11.('zc1');
zc1bar1=load('all_results','zc1bar');
zc1bar1=zc1bar1.('zc1bar');
zc12=load('all_results_L','zc1');
zc12=zc12.('zc1');
zc1bar2=load('all_results_L','zc1bar');
zc1bar2=zc1bar2.('zc1bar');
zc13=load('all_results_L2','zc1');
zc13=zc13.('zc1');
zc1bar3=load('all_results_L2','zc1bar');
zc1bar3=zc1bar3.('zc1bar');
zc14=load('all_results_L3','zc1');
zc14=zc14.('zc1');
zc1bar4=load('all_results_L3','zc1bar');
zc1bar4=zc1bar4.('zc1bar');

zc21=load('all_results','zc2');
zc21=zc21.('zc2');
zc2bar1=load('all_results','zc2bar');
zc2bar1=zc2bar1.('zc2bar');
zc22=load('all_results_L','zc2');
zc22=zc22.('zc2');
zc2bar2=load('all_results_L','zc2bar');
zc2bar2=zc2bar2.('zc2bar');
zc23=load('all_results_L2','zc2');
zc23=zc23.('zc2');
zc2bar3=load('all_results_L2','zc2bar');
zc2bar3=zc2bar3.('zc2bar');
zc24=load('all_results_L3','zc2');
zc24=zc24.('zc2');
zc2bar4=load('all_results_L3','zc2bar');
zc2bar4=zc2bar4.('zc2bar');

ii1=load('all_results','ii');
ii1=ii1.('ii');
ii2=load('all_results_L','ii');
ii2=ii2.('ii');
ii3=load('all_results_L2','ii');
ii3=ii3.('ii');
ii4=load('all_results_L3','ii');
ii4=ii4.('ii');


ss1=load('all_results','ss');
ss1=ss1.('ss');
ss2=load('all_results_L','ss');
ss2=ss2.('ss');
ss3=load('all_results_L2','ss');
ss3=ss3.('ss');
ss4=load('all_results_L3','ss');
ss4=ss4.('ss');

rr1=load('all_results','rr');
rr1=rr1.('rr');
rr2=load('all_results_L','rr');
rr2=rr2.('rr');
rr3=load('all_results_L2','rr');
rr3=rr3.('rr');
rr4=load('all_results_L3','rr');
rr4=rr4.('rr');

dd1=load('all_results','dd');
dd1=dd1.('dd');
dd2=load('all_results_L','dd');
dd2=dd2.('dd');
dd3=load('all_results_L2','dd');
dd3=dd3.('dd');
dd4=load('all_results_L3','dd');
dd4=dd4.('dd');


ia=4;
ib=4;
fsize=11;
horz=150;

time=0:1:horz-1;

figure;

subplot(ia,ib,1)
plot(time(1:end-1),0*100*(C11(2:horz)-C1bar1)/C1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C11(2:horz)-C1bar1)/C1bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(C12(2:horz)-C1bar2)/C1bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C12(2:horz)-C1bar2)/C1bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(C13(2:horz)-C1bar3)/C1bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C13(2:horz)-C1bar3)/C1bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(C14(2:horz)-C1bar4)/C1bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C14(2:horz)-C1bar4)/C1bar4,'y:','LineWidth',2);hold off
box off;
title('Consumption Social, C(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,2)
plot(time(1:end-1),0*100*(C1(2:horz)-Cbar1)/Cbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C1(2:horz)-Cbar1)/Cbar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(C2(2:horz)-Cbar2)/Cbar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C2(2:horz)-Cbar2)/Cbar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(C3(2:horz)-Cbar3)/Cbar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C3(2:horz)-Cbar3)/Cbar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(C4(2:horz)-Cbar4)/Cbar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C4(2:horz)-Cbar4)/Cbar4,'y:','LineWidth',2);hold off
box off;
title('Consumption, C','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,3)
plot(time(1:end-1),0*100*(GDP1(2:horz)-GDPbar1)/GDPbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(GDP1(2:horz)-GDPbar1)/GDPbar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(GDP2(2:horz)-GDPbar2)/GDPbar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(GDP2(2:horz)-GDPbar2)/GDPbar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(GDP3(2:horz)-GDPbar3)/GDPbar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(GDP3(2:horz)-GDPbar3)/GDPbar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(GDP4(2:horz)-GDPbar4)/GDPbar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(GDP4(2:horz)-GDPbar4)/GDPbar4,'y:','LineWidth',2);hold off
box off;
title('GDP, GDP','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,4)
plot(time(1:end-1),0*100*(w1(2:horz)-wbar1)/wbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(w1(2:horz)-wbar1)/wbar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(w2(2:horz)-wbar2)/wbar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(w2(2:horz)-wbar2)/wbar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(w3(2:horz)-wbar3)/wbar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(w3(2:horz)-wbar3)/wbar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(w4(2:horz)-wbar4)/wbar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(w4(2:horz)-wbar4)/wbar4,'y:','LineWidth',2);hold off
box off;
title('Wage, w','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,5)
plot(time(1:end-1),0*100*(no11(2:horz)-no1bar1)/no1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no11(2:horz)-no1bar1)/no1bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(no12(2:horz)-no1bar2)/no1bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no12(2:horz)-no1bar2)/no1bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(no13(2:horz)-no1bar3)/no1bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no13(2:horz)-no1bar3)/no1bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(no14(2:horz)-no1bar4)/no1bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no14(2:horz)-no1bar4)/no1bar4,'y:','LineWidth',2);hold off
box off;
title('Operative Social, no(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,6)
plot(time(1:end-1),0*100*(N11(2:horz)-N1bar1)/N1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N11(2:horz)-N1bar1)/N1bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(N12(2:horz)-N1bar2)/N1bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N12(2:horz)-N1bar2)/N1bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(N13(2:horz)-N1bar3)/N1bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N13(2:horz)-N1bar3)/N1bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(N14(2:horz)-N1bar4)/N1bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N14(2:horz)-N1bar4)/N1bar4,'y:','LineWidth',2);hold off
box off;
title('Firms Social, N(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,7)
plot(time(1:end-1),0*100*(Ne11(2:horz)-Ne1bar1)/Ne1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne11(2:horz)-Ne1bar1)/Ne1bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(Ne12(2:horz)-Ne1bar2)/Ne1bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne12(2:horz)-Ne1bar2)/Ne1bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(Ne13(2:horz)-Ne1bar3)/Ne1bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne13(2:horz)-Ne1bar3)/Ne1bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(Ne14(2:horz)-Ne1bar4)/Ne1bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne14(2:horz)-Ne1bar4)/Ne1bar4,'y:','LineWidth',2);hold off
box off;
title('Entrants Social, Ne(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,11)
plot(time(1:end-1),0*100*(Ne21(2:horz)-Ne2bar1)/Ne2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne21(2:horz)-Ne2bar1)/Ne2bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(Ne22(2:horz)-Ne2bar2)/Ne2bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne22(2:horz)-Ne2bar2)/Ne2bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(Ne23(2:horz)-Ne2bar3)/Ne2bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne23(2:horz)-Ne2bar3)/Ne2bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(Ne24(2:horz)-Ne2bar4)/Ne2bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne24(2:horz)-Ne2bar4)/Ne2bar4,'y:','LineWidth',2);hold off
box off;
title('Entrants Non-Social, Ne(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,8)
plot(time(1:end-1),0*100*(zc11(2:horz)-zc1bar1)/zc1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc11(2:horz)-zc1bar1)/zc1bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(zc12(2:horz)-zc1bar2)/zc1bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc12(2:horz)-zc1bar2)/zc1bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(zc13(2:horz)-zc1bar3)/zc1bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc13(2:horz)-zc1bar3)/zc1bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(zc14(2:horz)-zc1bar4)/zc1bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc14(2:horz)-zc1bar4)/zc1bar4,'y:','LineWidth',2);hold off
box off;
title('Cut-off Social, zc(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,9)
plot(time(1:end-1),0*100*(no21(2:horz)-no2bar1)/no2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no21(2:horz)-no2bar1)/no2bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(no22(2:horz)-no2bar2)/no2bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no22(2:horz)-no2bar2)/no2bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(no23(2:horz)-no2bar3)/no2bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no23(2:horz)-no2bar3)/no2bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(no24(2:horz)-no2bar4)/no2bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no24(2:horz)-no2bar4)/no2bar4,'y:','LineWidth',2);hold off
box off;
title('Operative Non-Social, no(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,10)
plot(time(1:end-1),0*100*(N21(2:horz)-N2bar1)/N2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N21(2:horz)-N2bar1)/N2bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(N22(2:horz)-N2bar2)/N2bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N22(2:horz)-N2bar2)/N2bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(N23(2:horz)-N2bar3)/N2bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N23(2:horz)-N2bar3)/N2bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(N24(2:horz)-N2bar4)/N2bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N24(2:horz)-N2bar4)/N2bar4,'y:','LineWidth',2);hold off
box off;
title('Firms Non-Social, N(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,12)
plot(time(1:end-1),0*100*(zc21(2:horz)-zc2bar1)/zc2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc21(2:horz)-zc2bar1)/zc2bar1,'g--','LineWidth',2);hold on
plot(time(1:end-1),0*100*(zc22(2:horz)-zc2bar2)/zc2bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc22(2:horz)-zc2bar2)/zc2bar2,'r-.','LineWidth',2);hold on
plot(time(1:end-1),0*100*(zc23(2:horz)-zc2bar3)/zc2bar3,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc23(2:horz)-zc2bar3)/zc2bar3,'b-','LineWidth',2);hold on
plot(time(1:end-1),0*100*(zc24(2:horz)-zc2bar4)/zc2bar4,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc24(2:horz)-zc2bar4)/zc2bar4,'y:','LineWidth',2);hold off
box off;
title('Cut-off Non-Social, zc(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,13)
plot(time,328000000*ii1(1:horz),'g--','LineWidth',2);hold on
plot(time,328000000*ii2(1:horz),'r-.','LineWidth',2);hold on
plot(time,328000000*ii3(1:horz),'b-','LineWidth',2);hold on
plot(time,328000000*ii4(1:horz),'y:','LineWidth',2);hold off
box off;
title('Infected, ii','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,14)
plot(time,328000000*ss1(1:horz),'g--','LineWidth',2);hold on
plot(time,328000000*ss2(1:horz),'r-.','LineWidth',2);hold on
plot(time,328000000*ss3(1:horz),'b-','LineWidth',2);hold on
plot(time,328000000*ss4(1:horz),'y:','LineWidth',2);hold off
box off;
title('Susceptibles, ss','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,15)
plot(time,328000000*rr1(1:horz),'g--','LineWidth',2);hold on
plot(time,328000000*rr2(1:horz),'r-.','LineWidth',2);hold on
plot(time,328000000*rr3(1:horz),'b-','LineWidth',2);hold on
plot(time,328000000*rr4(1:horz),'y:','LineWidth',2);hold off
box off;
title('Recovered, rr','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,16)
plot(time,328000000*dd1(1:horz),'g--','LineWidth',2);hold on
plot(time,328000000*dd2(1:horz),'r-.','LineWidth',2);hold on
plot(time,328000000*dd3(1:horz),'b-','LineWidth',2);hold on
plot(time,328000000*dd4(1:horz),'y:','LineWidth',2);hold off
box off;
title('Deaths, dd','FontSize',fsize);
xlabel('Weeks','FontSize',fsize);
set(gca,'FontSize',fsize);

legend('Benchmark',' Social Distancing, Permanent', 'Social Distancing, 6 Months', 'Social Distancing, 1 Year')

%subtitle('Figure 1: Simulation Results');
% orient landscape
% print -dpdf -fillpage fig_bench_vs_SD_noC2

savefig fig10.fig