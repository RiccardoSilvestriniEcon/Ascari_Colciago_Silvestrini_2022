%%%%%%%%%%%% ACS (2022). How to replicate paper Figures 9

%%%%%%%%%%%% 1) Run SS_benchmark to get steady state (same for all models)
%%%%%%%%%%%% output --> SS_for_dynare

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (use functions go_calibrate
%%%%%%%%%%%% and calibrate_pi) to store results and simulate response --> output
%%%%%%%%%%%% all_results_benchmark

%%%%%%%%%%%% 3) Run acs_benchmark_phy1 on dynare 4.4.3 (use functions go_calibrate
%%%%%%%%%%%% and calibrate_pi) to store results and simulate response with 
%%%%%%%%%%%% alternative Taylor rule tr_phy=1/52 --> output: all_results_phy1

%%%%%%%%%%%% 4) Run acs_benchmark_phy2 on dynare 4.4.3 (use functions go_calibrate
%%%%%%%%%%%% and calibrate_pi) to store results and simulate response with 
%%%%%%%%%%%% alternative Taylor rule tr_phy=2/52 --> output: all_results_phy2

%%%%%%%%%%%% 5) Run acs_benchmark_phy3 on dynare 4.4.3 (use functions go_calibrate
%%%%%%%%%%%% and calibrate_pi) to store results and simulate response with 
%%%%%%%%%%%% alternative Taylor rule tr_phy=3/52 --> output: all_results_phy3

%%%%%%%%%%%% 6) Run plot_all_phys for figure 9 in the paper --> output:
%%%%%%%%%%%% Figure9.fig and Figure9.png.
