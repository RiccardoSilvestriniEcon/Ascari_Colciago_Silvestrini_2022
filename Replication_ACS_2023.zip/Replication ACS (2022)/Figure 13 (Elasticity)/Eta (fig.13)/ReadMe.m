%%%%%%%%%%%%%%%%% How to replicate paper Figure 13:

%%%%%%%%%%%% 1) Run SS_benchmark/_higheta/_loweta to store steady states of
%%%%%%%%%%%% the economy, different levels of eta. Output: SS_for_dynare,
%%%%%%%%%%%% SS_for_dynare_HT, SS_for_dynare_LT

%%%%%%%%%%%% 2) Run acs_benchmark/_higheta/_loweta on dynare 4.4.3 (use 
%%%%%%%%%%%% go_calibrate and calibrate_pi) to store results and simulate 
%%%%%%%%%%%% model with different etas --> output: all_results, all_results_HT, 
%%%%%%%%%%%% all_results_LT

%%%%%%%%%%%% 3) Run plot_paper for Figure 13, output fig13.fig -->
%%%%%%%%%%%% Figure13.fig and Figure13.png.
