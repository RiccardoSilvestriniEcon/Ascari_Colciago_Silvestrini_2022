%%%%%%%%%%%%%%%%% How to replicate paper, robustness different theta.

%%%%%%%%%%%% 1) Run SS_banchmark/_hightheta/_lowtheta to store steady states 
%%%%%%%%%%%% of the economy, different levels of theta. Output:
%%%%%%%%%%%% SS_for_dynare, SS_for_dynare_HT, SS_for_dynare_LT

%%%%%%%%%%%% 2) Run acs_benchmark/_hightheta/_lowtheta on dynare 4.4.3 (use 
%%%%%%%%%%%% go_calibrate and calibrate_pi) to store results and simulate 
%%%%%%%%%%%% model with different thetas --> output: all_results, 
%%%%%%%%%%%% all_results_HT, all_results_LT

%%%%%%%%%%%% 3) Run plot_paper for comparison simulations.
