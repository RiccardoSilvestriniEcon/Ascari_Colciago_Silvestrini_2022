load all_results;

for i=2:522
    pi_s(i,1)=rho_s(i,1)/rho_s(i-1,1);
    pi_ns(i,1)=rho_ns(i,1)/rho_ns(i-1,1);
end
    pi_s(1,1)=1;
    pi_ns(1,1)=1;

load CPI_BLS;

CPI=table2array(CPIBLS);

CPI=str2double(CPI);

for i=1:2
    for j=1:12
        CPI_data((i-1)*12+j,1)=CPI(i,j+1);
    end
end

for i=1:24
    CPI_plot(i,1)=100*(CPI_data(i,1)-CPI_data(1,1))/CPI_data(1,1);
end

%%%

load CPI_delivery_BLS;

CPIdelivery=table2array(CPIdeliveryBLS);

CPIdelivery=str2double(CPIdelivery);

for i=1:2
    for j=1:12
        CPIdelivery_data((i-1)*12+j,1)=CPIdelivery(i,j+1);
    end
end

for i=1:24
    CPIdelivery_plot(i,1)=100*(CPIdelivery_data(i,1)-CPIdelivery_data(1,1))/CPIdelivery_data(1,1);
end

%%%

load CPI_energy_BLS;

CPIenergy=table2array(CPIenergyBLS);

CPIenergy=str2double(CPIenergy);

for i=1:2
    for j=1:12
        CPIenergy_data((i-1)*12+j,1)=CPIenergy(i,j+1);
    end
end

for i=1:24
    CPIenergy_plot(i,1)=100*(CPIenergy_data(i,1)-CPIenergy_data(1,1))/CPIenergy_data(1,1);
end

%%%

load CPI_infotech_BLS;

CPIinfotech=table2array(CPIinfotechBLS);

CPIinfotech=str2double(CPIinfotech);

for i=1:2
    for j=1:12
        CPIinfotech_data((i-1)*12+j,1)=CPIinfotech(i,j+1);
    end
end

for i=1:24
    CPIinfotech_plot(i,1)=100*(CPIinfotech_data(i,1)-CPIinfotech_data(1,1))/CPIinfotech_data(1,1);
end

%%%

load CPI_services_BLS;

CPIservices=table2array(CPIservicesBLS);

CPIservices=str2double(CPIservices);

for i=1:2
    for j=1:12
        CPIservices_data((i-1)*12+j,1)=CPIservices(i,j+1);
    end
end

for i=1:24
    CPIservices_plot(i,1)=100*(CPIservices_data(i,1)-CPIservices_data(1,1))/CPIservices_data(1,1);
end

%%%

load CPI_education_BLS;

CPIeducation=table2array(CPIeducationBLS);

CPIeducation=str2double(CPIeducation);

for i=1:2
    for j=1:12
        CPIeducation_data((i-1)*12+j,1)=CPIeducation(i,j+1);
    end
end

for i=1:24
    CPIeducation_plot(i,1)=100*(CPIeducation_data(i,1)-CPIeducation_data(1,1))/CPIeducation_data(1,1);
end

%%%

load CPI_medicare_BLS;

CPImedicare=table2array(CPImedicareBLS);

CPImedicare=str2double(CPImedicare);

for i=1:2
    for j=1:12
        CPImedicare_data((i-1)*12+j,1)=CPImedicare(i,j+1);
    end
end

for i=1:24
    CPImedicare_plot(i,1)=100*(CPImedicare_data(i,1)-CPImedicare_data(1,1))/CPImedicare_data(1,1);
end

%%%

load CPI_recreation_BLS;

CPIrecreation=table2array(CPIrecreationBLS);

CPIrecreation=str2double(CPIrecreation);

for i=1:2
    for j=1:12
        CPIrecreation_data((i-1)*12+j,1)=CPIrecreation(i,j+1);
    end
end

for i=1:24
    CPIrecreation_plot(i,1)=100*(CPIrecreation_data(i,1)-CPIrecreation_data(1,1))/CPIrecreation_data(1,1);
end

%%%

load CPI_trans_serv_BLS;

CPItrans_serv=table2array(CPItransservBLS);

CPItrans_serv=str2double(CPItrans_serv);

for i=1:2
    for j=1:12
        CPItrans_serv_data((i-1)*12+j,1)=CPItrans_serv(i,j+1);
    end
end

for i=1:24
    CPItrans_serv_plot(i,1)=100*(CPItrans_serv_data(i,1)-CPItrans_serv_data(1,1))/CPItrans_serv_data(1,1);
end

%%%%% transform monthly data:

for i=1:24
    pi_Q(i)=pi(1+(i-1)*4)*pi(2+(i-1)*4)*pi(3+(i-1)*4)*pi(4+(i-1)*4);
end

for i=1:24
    pi_s_Q(i)=pi_s(1+(i-1)*4)*pi_s(2+(i-1)*4)*pi_s(3+(i-1)*4)*pi_s(4+(i-1)*4);
end

for i=1:24
    pi_ns_Q(i)=pi_ns(1+(i-1)*4)*pi_ns(2+(i-1)*4)*pi_ns(3+(i-1)*4)*pi_ns(4+(i-1)*4);
end

%plotting
fsize=11;
horz=100;

time=0:1:horz-1;

figure(1);

subplot(1,2,1)
plot(time(1:12),12*0*100*(pi_Q(1:12)-1)/1,'m:','LineWidth',1.5);hold on
plot(time(1:12),12*100*(pi_Q(1:12)-1)/1,'b-','LineWidth',2);hold off
box off;
title('Inflation Model','FontSize',fsize);
set(gca,'FontSize',fsize);
xticks([0 3 6 9]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(1,2,2)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPI_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

figure(2);

subplot(2,5,1)
plot(time(1:12),12*0*100*(pi_s_Q(1:12)-1)/1,'m:','LineWidth',1.5);hold on
plot(time(1:12),12*100*(pi_s_Q(1:12)-1)/1,'b-','LineWidth',2);hold off
box off;
title('Inflation Social Model','FontSize',fsize);
set(gca,'FontSize',fsize);
xticks([0 3 6 9]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,2)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIeducation_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Education','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,3)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPImedicare_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Medical Care','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,4)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIrecreation_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Recreation','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,5)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPItrans_serv_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Transport Services','FontSize',fsize);
set(gca,'FontSize',fsize);
xticks([0 3 6 9]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,6)
plot(time(1:12),12*0*100*(pi_ns_Q(1:12)-1)/1,'m:','LineWidth',1.5);hold on
plot(time(1:12),12*100*(pi_ns_Q(1:12)-1)/1,'b-','LineWidth',2);hold off
box off;
title('Inflation non-Social Model','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,7)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIdelivery_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Delivery','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,8)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIenergy_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Energy','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,9)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIinfotech_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Information Technology','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});

subplot(2,5,10)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIservices_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Data, Services','FontSize',fsize);
set(gca,'FontSize',fsize);
xlim([1 12]);
xticks([1 4 7 10]);
xticklabels({'Jan-20', 'Apr-20', 'Jul-20', 'Oct-20'});