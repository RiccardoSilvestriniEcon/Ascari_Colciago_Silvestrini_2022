load all_results;

for i=2:522
    pi_ns(i,1)=rho_ns(i,1)/rho_ns(i-1,1);
end

pi_ns(1,1)=1;

%%%

load CPI_communication_BLS;

CPIcommunication=table2array(CPIcommunicationBLS);

CPIcommunication=str2double(CPIcommunication);

for i=1:2
    for j=1:12
        CPIcommunication_data((i-1)*12+j,1)=CPIcommunication(i,j+1);
    end
end

for i=1:24
    CPIcommunication_plot(i,1)=100*(CPIcommunication_data(i,1)-CPIcommunication_data(1,1))/CPIcommunication_data(1,1);
end

%%%

load CPI_delivery_BLS;

CPIdelivery=table2array(CPIdeliveryBLS);

CPIdelivery=str2double(CPIdelivery);

for i=1:2
    for j=1:12
        CPIdelivery_data((i-1)*12+j,1)=CPIdelivery(i,j+1);
    end
end

for i=1:24
    CPIdelivery_plot(i,1)=100*(CPIdelivery_data(i,1)-CPIdelivery_data(1,1))/CPIdelivery_data(1,1);
end

%%%

load CPI_energy_BLS;

CPIenergy=table2array(CPIenergyBLS);

CPIenergy=str2double(CPIenergy);

for i=1:2
    for j=1:12
        CPIenergy_data((i-1)*12+j,1)=CPIenergy(i,j+1);
    end
end

for i=1:24
    CPIenergy_plot(i,1)=100*(CPIenergy_data(i,1)-CPIenergy_data(1,1))/CPIenergy_data(1,1);
end


%%%

load CPI_fuel_BLS;

CPIfuel=table2array(CPIfuelBLS);

CPIfuel=str2double(CPIfuel);

for i=1:2
    for j=1:12
        CPIfuel_data((i-1)*12+j,1)=CPIfuel(i,j+1);
    end
end

for i=1:24
    CPIfuel_plot(i,1)=100*(CPIfuel_data(i,1)-CPIfuel_data(1,1))/CPIfuel_data(1,1);
end

%%%

load CPI_information_BLS;

CPIinformation=table2array(CPIinformationBLS);

CPIinformation=str2double(CPIinformation);

for i=1:2
    for j=1:12
        CPIinformation_data((i-1)*12+j,1)=CPIinformation(i,j+1);
    end
end

for i=1:24
    CPIinformation_plot(i,1)=100*(CPIinformation_data(i,1)-CPIinformation_data(1,1))/CPIinformation_data(1,1);
end

%%%

load CPI_infotech_BLS;

CPIinfotech=table2array(CPIinfotechBLS);

CPIinfotech=str2double(CPIinfotech);

for i=1:2
    for j=1:12
        CPIinfotech_data((i-1)*12+j,1)=CPIinfotech(i,j+1);
    end
end

for i=1:24
    CPIinfotech_plot(i,1)=100*(CPIinfotech_data(i,1)-CPIinfotech_data(1,1))/CPIinfotech_data(1,1);
end

%%%

load CPI_professionals_BLS;

CPIprofessionals=table2array(CPIprofessionalsBLS);

CPIprofessionals=str2double(CPIprofessionals);

for i=1:2
    for j=1:12
        CPIprofessionals_data((i-1)*12+j,1)=CPIprofessionals(i,j+1);
    end
end

for i=1:24
    CPIprofessionals_plot(i,1)=100*(CPIprofessionals_data(i,1)-CPIprofessionals_data(1,1))/CPIprofessionals_data(1,1);
end

%%%

load CPI_services_BLS;

CPIservices=table2array(CPIservicesBLS);

CPIservices=str2double(CPIservices);

for i=1:2
    for j=1:12
        CPIservices_data((i-1)*12+j,1)=CPIservices(i,j+1);
    end
end

for i=1:24
    CPIservices_plot(i,1)=100*(CPIservices_data(i,1)-CPIservices_data(1,1))/CPIservices_data(1,1);
end


%%%%% transform monthly data:

for i=1:24
    pi_ns_Q(i)=pi_ns(1+(i-1)*4)*pi_ns(2+(i-1)*4)*pi_ns(3+(i-1)*4)*pi_ns(4+(i-1)*4);
end

%plotting
fsize=11;
horz=100;

time=0:1:horz-1;

figure(1);

subplot(3,4,1)
plot(time(1:12),12*0*100*(pi_ns_Q(1:12)-1)/1,'m:','LineWidth',1.5);hold on
plot(time(1:12),12*100*(pi_ns_Q(1:12)-1)/1,'b-','LineWidth',2);hold off
box off;
title('Inflation non-Social Model','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,5)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIcommunication_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Communication','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,6)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIdelivery_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Delivery','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,7)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIenergy_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Energy','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,8)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIfuel_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Fuel','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,9)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIinformation_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Information','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,10)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIinfotech_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Information Technology','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,11)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIprofessionals_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Professional Services','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(3,4,12)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIservices_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Services','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);