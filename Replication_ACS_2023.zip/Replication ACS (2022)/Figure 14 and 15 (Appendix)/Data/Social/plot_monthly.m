load all_results;

for i=2:522
    pi_s(i,1)=rho_s(i,1)/rho_s(i-1,1);
end

pi_s(1,1)=1;

%%%

load CPI_airlines_BLS;

CPIairlines=table2array(CPIairlinesBLS);

CPIairlines=str2double(CPIairlines);

for i=1:2
    for j=1:12
        CPIairlines_data((i-1)*12+j,1)=CPIairlines(i,j+1);
    end
end

for i=1:24
    CPIairlines_plot(i,1)=100*(CPIairlines_data(i,1)-CPIairlines_data(1,1))/CPIairlines_data(1,1);
end

%%%

load CPI_education_BLS;

CPIeducation=table2array(CPIeducationBLS);

CPIeducation=str2double(CPIeducation);

for i=1:2
    for j=1:12
        CPIeducation_data((i-1)*12+j,1)=CPIeducation(i,j+1);
    end
end

for i=1:24
    CPIeducation_plot(i,1)=100*(CPIeducation_data(i,1)-CPIeducation_data(1,1))/CPIeducation_data(1,1);
end

%%%

load CPI_food_BLS;

CPIfood=table2array(CPIfoodBLS);

CPIfood=str2double(CPIfood);

for i=1:2
    for j=1:12
        CPIfood_data((i-1)*12+j,1)=CPIfood(i,j+1);
    end
end

for i=1:24
    CPIfood_plot(i,1)=100*(CPIfood_data(i,1)-CPIfood_data(1,1))/CPIfood_data(1,1);
end


%%%

load CPI_hospitals_BLS;

CPIhospitals=table2array(CPIhospitalsBLS);

CPIhospitals=str2double(CPIhospitals);

for i=1:2
    for j=1:12
        CPIhospitals_data((i-1)*12+j,1)=CPIhospitals(i,j+1);
    end
end

for i=1:24
    CPIhospitals_plot(i,1)=100*(CPIhospitals_data(i,1)-CPIhospitals_data(1,1))/CPIhospitals_data(1,1);
end

%%%

load CPI_housing_BLS;

CPIhousing=table2array(CPIhousingBLS);

CPIhousing=str2double(CPIhousing);

for i=1:2
    for j=1:12
        CPIhousing_data((i-1)*12+j,1)=CPIhousing(i,j+1);
    end
end

for i=1:24
    CPIhousing_plot(i,1)=100*(CPIhousing_data(i,1)-CPIhousing_data(1,1))/CPIhousing_data(1,1);
end

%%%

load CPI_medicare_BLS;

CPImedicare=table2array(CPImedicareBLS);

CPImedicare=str2double(CPImedicare);

for i=1:2
    for j=1:12
        CPImedicare_data((i-1)*12+j,1)=CPImedicare(i,j+1);
    end
end

for i=1:24
    CPImedicare_plot(i,1)=100*(CPImedicare_data(i,1)-CPImedicare_data(1,1))/CPImedicare_data(1,1);
end

%%%

load CPI_p_transport_BLS;

CPIp_transport=table2array(CPIptransportBLS);

CPIp_transport=str2double(CPIp_transport);

for i=1:2
    for j=1:12
        CPIp_transport_data((i-1)*12+j,1)=CPIp_transport(i,j+1);
    end
end

for i=1:24
    CPIp_transport_plot(i,1)=100*(CPIp_transport_data(i,1)-CPIp_transport_data(1,1))/CPIp_transport_data(1,1);
end

%%%

load CPI_recreation_BLS;

CPIrecreation=table2array(CPIrecreationBLS);

CPIrecreation=str2double(CPIrecreation);

for i=1:2
    for j=1:12
        CPIrecreation_data((i-1)*12+j,1)=CPIrecreation(i,j+1);
    end
end

for i=1:24
    CPIrecreation_plot(i,1)=100*(CPIrecreation_data(i,1)-CPIrecreation_data(1,1))/CPIrecreation_data(1,1);
end

%%%

load CPI_trans_BLS;

CPItrans=table2array(CPItransBLS);

CPItrans=str2double(CPItrans);

for i=1:2
    for j=1:12
        CPItrans_data((i-1)*12+j,1)=CPItrans(i,j+1);
    end
end

for i=1:24
    CPItrans_plot(i,1)=100*(CPItrans_data(i,1)-CPItrans_data(1,1))/CPItrans_data(1,1);
end

%%%

load CPI_trans_serv_BLS;

CPItrans_serv=table2array(CPItransservBLS);

CPItrans_serv=str2double(CPItrans_serv);

for i=1:2
    for j=1:12
        CPItrans_serv_data((i-1)*12+j,1)=CPItrans_serv(i,j+1);
    end
end

for i=1:24
    CPItrans_serv_plot(i,1)=100*(CPItrans_serv_data(i,1)-CPItrans_serv_data(1,1))/CPItrans_serv_data(1,1);
end


%%%%% transform monthly data:

for i=1:24
    pi_s_Q(i)=pi_s(1+(i-1)*4)*pi_s(2+(i-1)*4)*pi_s(3+(i-1)*4)*pi_s(4+(i-1)*4);
end

%plotting
fsize=11;
horz=100;

time=0:1:horz-1;

figure(1);

subplot(4,4,1)
plot(time(1:12),12*0*100*(pi_s_Q(1:12)-1)/1,'m:','LineWidth',1.5);hold on
plot(time(1:12),12*100*(pi_s_Q(1:12)-1)/1,'b-','LineWidth',2);hold off
box off;
title('Inflation Social Model','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,5)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIairlines_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Airlines','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,6)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIeducation_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Education','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,7)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIfood_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Food','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,8)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIhospitals_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Hospitals','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,9)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIhousing_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Housing','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,10)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPImedicare_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Medical Care','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,11)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIp_transport_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Public Transport','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,12)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPIrecreation_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Recreation','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,13)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPItrans_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Transportation','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);

subplot(4,4,14)
plot(1:12,0,'m:','LineWidth',1.5);hold on
plot(1:12,12*CPItrans_serv_plot(1:12),'b-','LineWidth',2);hold off
box off;
title('Inflation Transportation Services','FontSize',fsize);
set(gca,'FontSize',fsize);

xlabel('Months','FontSize',fsize);