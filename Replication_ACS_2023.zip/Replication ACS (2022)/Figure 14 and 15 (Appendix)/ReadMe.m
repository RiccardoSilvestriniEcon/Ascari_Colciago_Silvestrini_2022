%%%%%%%%%%%% ACS (2023). How to plot (sectoral) inflation, Figures 14 and
%%%%%%%%%%%% 15

%%%%%%%%%%%% 1) Run SS_benchmark to store steady state (output: SS_for_dynare).

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (functions go_calibrate 
%%%%%%%%%%%% and calibrate_pi) to store results (output: all_results).

%%%%%%%%%%%% 3) Run plot_monthly for comparion inflation(s). input:
%%%%%%%%%%%% series for CPI_BLS, CPI_..._BLS from "Data" for (selected)
%%%%%%%%%%%% sectoral series. Output --> Figure12.fig and Figure14.png, and
%%%%%%%%%%%% Figure15.fig and Figure15.png.