clear all

load Cyc_labor_prod

startDate = datenum('01-04-2020');
endDate = datenum('01-01-2021');
xData = linspace(startDate,endDate,4);

load all_results
load all_results_L

Ztilde1=load('all_results','Ztilde');
Ztilde1=Ztilde1.('Ztilde');
Ztildebar1=load('all_results','Ztildebar');
Ztildebar1=Ztildebar1.('Ztildebar');

Ztilde2=load('all_results_L','Ztilde');
Ztilde2=Ztilde2.('Ztilde');
Ztildebar2=load('all_results_L','Ztildebar');
Ztildebar2=Ztildebar2.('Ztildebar');

figure(1)

subplot(1,3,2)
plot(100*(Ztilde1(6:42)-Ztildebar1)/Ztildebar1,'b-','LineWidth',2);
xticks([0 13 26 40]);
xticklabels({'Q2-20', 'Q3-20', 'Q4-20', 'Q1-21'});
title('Aggregate Productivity Model');

subplot(1,3,3)
plot(100*(Ztilde2(6:42)-Ztildebar2)/Ztildebar2,'b-','LineWidth',2);
xticks([0 13 26 40]);
xticklabels({'Q2-20', 'Q3-20', 'Q4-20', 'Q1-21'});
title('Aggregate Productivity Model, Lockdown');

subplot(1,3,1)
plot(xData,100*Cyc_labor_prod(294:297),'b-','LineWidth',2)
ax = gca; 
ax.XTick = xData(1:1:4);
datetick('x','QQ-YY','Keepticks')
xticks
xlim([startDate endDate]);
xticklabels({'Q2-20', 'Q3-20', 'Q4-20', 'Q1-21'});
title('Aggregate Productivity Data');

figure (2)

subplot(1,1,1)
plot(100*(Ztilde2(6:42)-Ztildebar2)/Ztildebar2,'b-','LineWidth',2);hold on
plot(100*(Ztilde1(6:42)-Ztildebar1)/Ztildebar1,'r-.','LineWidth',2);hold on
plot([0 13 26 40],[100*Cyc_labor_prod(294),100*Cyc_labor_prod(295),100*Cyc_labor_prod(296),100*Cyc_labor_prod(297)],'m:','LineWidth',2);hold off
xticks([0 13 26 40]);
xticklabels({'Q2-20', 'Q3-20', 'Q4-20', 'Q1-21'});
legend('Aggregate Productivity Model, Lockdown','Aggregate Productivity Model','Aggregate Productivity Data')
