%%%%%%%%%%%% ACS (2023). How to replicate paper, Lockdown US. Figure 11

%%%%%%%%%%%% Run SS_benchmark to store steady state --> output: SS_for_dynare 
%%%%%%%%%%%% (same for both models).

%%%%%%%%%%%% Run acs_benchmark on dynare 4.4.3 (use functions go_calibrate 
%%%%%%%%%%%% and calibrate_pi) to store results and simulate benchmark 
%%%%%%%%%%%% response --> output: all_results.

%%%%%%%%%%%% Run acs_benchmark_lockdown on dynare 4.4.3 (use functions 
%%%%%%%%%%%% go_calibrate and calibrate_pi) to store results and simulate 
%%%%%%%%%%%% response --> output: all_results_L.

%%%%%%%%%%%% Run plot_prod_paper for comparison labor productivity (input:
%%%%%%%%%%%% Cyc_labor_prod (labor productivity US in the data) --> output:
%%%%%%%%%%%% Figure11.fig and Figure11.png.

%%%%%%%%%%%% Run plot_simulation for comparison baseline vs. lockdown.