%%%% Codes and data for Figure 3

%%%% raw data comes from BFS monthly data on Business Applications (data
%%%% available at https://www.census.gov/econ/bfs/current/index.html)
%%%% (Csector.mat groups the series together, non-social sectors).

%%%%%% hpfilter routine (Folder Figure 4) MATLAB Econometric toolbox are
%%%%%% required.

%%%%%% plot_nonsocial uses raw inputs to plot the cyclical component of
%%%%%% business application for the non-social sectors --> output: Figure3.fig
%%%%%% and Figure3.png.