% computes percentage deviation from trend of the business applications 
clear all
load Csector


% compute trend and cyclical components of the levels 


[agriculture_trend,Cyc_agriculture] = hpfilter(agriculture,14400);
[admin_trend,Cyc_admin] = hpfilter(admin_support,14400);
[construction_trend,Cyc_construction] = hpfilter(construction,14400);
[fin_insu_trend,Cyc_fin_insu] = hpfilter(fin_insu,14400);
[info_serv_trend,Cyc_info_serv] = hpfilter(information,14400);
[manag_comp_trend,Cyc_manag_comp] = hpfilter(manag_compa,14400);
[mining_trend,Cyc_mining] = hpfilter(mining,14400);
[prof_serv_trend,Cyc_prof_serv] = hpfilter(prof_serv,14400);
[wholesale_trend,Cyc_wholesale] = hpfilter(wholesale,14400);
[utilities_trend,Cyc_utilities] = hpfilter(utilities,14400);

startDate = datenum('01-01-2019');
endDate = datenum('03-01-2021');
xData = linspace(startDate,endDate,27);


figure(1)

subplot(5,2,1)
plot(xData,Cyc_admin(169:195)./admin_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(i) Administrative and support services')


subplot(5,2,2)
plot(xData,Cyc_agriculture(169:195)./agriculture_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(ii) Agriculture')
xlim([startDate endDate]);


subplot(5,2,3)
plot(xData,Cyc_fin_insu(169:195)./fin_insu_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(iii) Finance and insurance')
xlim([startDate endDate]);


subplot(5,2,4)
plot(xData,Cyc_info_serv(169:195)./info_serv_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(iv) Information Services')
xlim([startDate endDate]);

subplot(5,2,5)
plot(xData,Cyc_manag_comp(169:195)./manag_comp_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(v) Management of companies')
xlim([startDate endDate]);


subplot(5,2,6)
plot(xData,Cyc_mining(169:195)./mining_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(vi) Mining')
xlim([startDate endDate]);


subplot(5,2,7)
plot(xData,Cyc_prof_serv(169:195)./prof_serv_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(vii) Professional services')
xlim([startDate endDate]);


subplot(5,2,8)
plot(xData,Cyc_utilities(169:195)./utilities_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title(' (viii) Utilities')
xlim([startDate endDate]);


subplot(5,2,9)
plot(xData,Cyc_wholesale(169:195)./wholesale_trend(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title(' (ix) Wholesale trade')
xlim([startDate endDate]);

sgtitle('Non-Social Sectors')

