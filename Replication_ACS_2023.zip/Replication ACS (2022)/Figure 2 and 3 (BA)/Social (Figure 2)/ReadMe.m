%%%% Codes and data for Figure 2

%%%% raw data comes from BFS monthly data on Business Applications (data
%%%% available at https://www.census.gov/econ/bfs/current/index.html)
%%%% (Ssector.mat groups the series together).

%%%%%% hpfilter routine (Folder Figure 4) MATLAB Econometric toolbox are
%%%%%% required.

%%%%%% plot_social uses raw inputs to plot the cyclical component of
%%%%%% business application for the social sectors --> output: Figure2.fig
%%%%%% and Figure2.png.