% computes percentage deviation from trend of the business applications 

clear all

load Ssector
load transport 

log_acc_food=log(acc_food_serv);
log_arts_enter=log(arts_enter);
log_edu=log(edu_serv);
log_health=log(health_soc);
log_real_esta=log(real_esta);
log_retail=log(retail_tra);
log_transport=log(transport);

% compute trend and cyclical compont of the logarithm, in this case the
% cyclical component will be in percentage

[acc_food_trend,Cyc_acc_food] = hpfilter(log_acc_food,14400);
[arts_enter_trend,Cyc_arts_enter] = hpfilter(log_arts_enter,14400);
[edu_trend,Cyc_edu] = hpfilter(log_edu,14400);
[health_trend,Cyc_health] = hpfilter(log_health,14400);
[real_esta_trend,Cyc_real_esta] = hpfilter(log_real_esta,14400);
[retail_trend,Cyc_retail] = hpfilter(log_retail,14400);
[transport_trend,Cyc_transport] = hpfilter(log_transport,14400);



startDate = datenum('01-01-19');
endDate = datenum('03-01-21');
xData = linspace(startDate,endDate,27);



figure(1)

subplot(4,2,1)
plot(xData,Cyc_acc_food(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);
title('(i) Accomodation and Food')


subplot(4,2,2)
plot(xData,Cyc_arts_enter(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
xlim([startDate endDate]);title('(ii) Arts and Entertainment')


subplot(4,2,3)
plot(xData,Cyc_edu(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
title('(iii) Educational Services')


subplot(4,2,4)
plot(xData,Cyc_health(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
title('(iv) Health and Social Services')


subplot(4,2,5)
plot(xData,Cyc_real_esta(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
title('(v) Real Estate')


subplot(4,2,6)
plot(xData,Cyc_transport(175:201)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
title('(vi) Transportation and warehousing')


subplot(4,2,7)
plot(xData,Cyc_retail(169:195)*100,'b','LineWidth',3)
ax = gca; 
ax.XTick = xData(1:2:27);
datetick('x','mmmyy','Keepticks')
xticks
xtickangle(15)
title('(vii) Retail Trade')

sgtitle('Social Sectors')