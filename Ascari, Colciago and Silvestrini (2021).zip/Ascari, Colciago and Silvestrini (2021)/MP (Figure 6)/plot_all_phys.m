clear all;

% Guido's code 2 August 2021
% The code loads mat files called all_results_phyX
% with different values of tr_y = coefficient of the Taylor rule on output
% all_results_phy1 => tr_y = 1/52= 0.0192
% all_results_phy2 => tr_y = 2/52= 0.0385
% all_results_phy3 => tr_y = 3/52= 0.0577
% all_results_benchmark => tr_y = 0.5/52= 0.0096


Y1=load('all_results_phy1','Y');
Y1=Y1.('Y');
Ybar1=load('all_results_phy1','Ybar');
Ybar1=Ybar1.('Ybar');
Y2=load('all_results_benchmark','Y');
Y2=Y2.('Y');
Ybar2=load('all_results_benchmark','Ybar');
Ybar2=Ybar2.('Ybar');
Y3=load('all_results_phy3','Y');
Y3=Y3.('Y');
Ybar3=load('all_results_phy3','Ybar');
Ybar3=Ybar3.('Ybar');
Y4=load('all_results_phy2','Y');
Y4=Y4.('Y');
Ybar4=load('all_results_phy2','Ybar');
Ybar4=Ybar4.('Ybar');




X1=load('all_results_phy1','X');
X1=X1.('X');
Xbar1=load('all_results_phy1','Xbar');
Xbar1=Xbar1.('Xbar');
X2=load('all_results_benchmark','X');
X2=X2.('X');
Xbar2=load('all_results_benchmark','Xbar');
Xbar2=Xbar2.('Xbar');
X3=load('all_results_phy3','X');
X3=X3.('X');
Xbar3=load('all_results_phy3','Xbar');
Xbar3=Xbar3.('Xbar');
X4=load('all_results_phy2','X');
X4=X4.('X');
Xbar4=load('all_results_phy2','Xbar');
Xbar4=Xbar4.('Xbar');



GDP1=load('all_results_phy1','GDP');
GDP1=GDP1.('GDP');
GDPbar1=load('all_results_phy1','GDPbar');
GDPbar1=GDPbar1.('GDPbar');
GDP2=load('all_results_benchmark','GDP');
GDP2=GDP2.('GDP');
GDPbar2=load('all_results_benchmark','GDPbar');
GDPbar2=GDPbar2.('GDPbar');
GDP3=load('all_results_phy3','GDP');
GDP3=GDP3.('GDP');
GDPbar3=load('all_results_phy3','GDPbar');
GDPbar3=GDPbar3.('GDPbar');
GDP4=load('all_results_phy2','GDP');
GDP4=GDP4.('GDP');
GDPbar4=load('all_results_phy2','GDPbar');
GDPbar4=GDPbar4.('GDPbar');


C1=load('all_results_phy1','C');
C1=C1.('C');
Cbar1=load('all_results_phy1','Cbar');
Cbar1=Cbar1.('Cbar');
C2=load('all_results_benchmark','C');
C2=C2.('C');
Cbar2=load('all_results_benchmark','Cbar');
Cbar2=Cbar2.('Cbar');
C3=load('all_results_phy3','C');
C3=C3.('C');
Cbar3=load('all_results_phy3','Cbar');
Cbar3=Cbar3.('Cbar');
C4=load('all_results_phy2','C');
C4=C4.('C');
Cbar4=load('all_results_phy2','Cbar');
Cbar4=Cbar4.('Cbar');


C11=load('all_results_phy1','C1');
C11=C11.('C1');
C1bar1=load('all_results_phy1','C1bar');
C1bar1=C1bar1.('C1bar');
C12=load('all_results_benchmark','C1');
C12=C12.('C1');
C1bar2=load('all_results_benchmark','C1bar');
C1bar2=C1bar2.('C1bar');
C13=load('all_results_phy3','C1');
C13=C13.('C1');
C1bar3=load('all_results_phy3','C1bar');
C1bar3=C1bar3.('C1bar');
C14=load('all_results_phy2','C1');
C14=C14.('C1');
C1bar4=load('all_results_phy2','C1bar');
C1bar4=C1bar4.('C1bar');


C21=load('all_results_phy1','C2');
C21=C21.('C2');
C2bar1=load('all_results_phy1','C2bar');
C2bar1=C2bar1.('C2bar');
C22=load('all_results_benchmark','C2');
C22=C22.('C2');
C2bar2=load('all_results_benchmark','C2bar');
C2bar2=C2bar2.('C2bar');
C23=load('all_results_phy3','C2');
C23=C23.('C2');
C2bar3=load('all_results_phy3','C2bar');
C2bar3=C2bar3.('C2bar');
C24=load('all_results_phy2','C2');
C24=C24.('C2');
C2bar4=load('all_results_phy2','C2bar');
C2bar4=C2bar4.('C2bar');


ls1=load('all_results_phy1','ls');
ls1=ls1.('ls');
lsbar1=load('all_results_phy1','lsbar');
lsbar1=lsbar1.('lsbar');
ls2=load('all_results_benchmark','ls');
ls2=ls2.('ls');
lsbar2=load('all_results_benchmark','lsbar');
lsbar2=lsbar2.('lsbar');
ls3=load('all_results_phy3','ls');
ls3=ls3.('ls');
lsbar3=load('all_results_phy3','lsbar');
lsbar3=lsbar3.('lsbar');
ls4=load('all_results_phy2','ls');
ls4=ls4.('ls');
lsbar4=load('all_results_phy2','lsbar');
lsbar4=lsbar4.('lsbar');


w1=load('all_results_phy1','w');
w1=w1.('w');
wbar1=load('all_results_phy1','wbar');
wbar1=wbar1.('wbar');
w2=load('all_results_benchmark','w');
w2=w2.('w');
wbar2=load('all_results_benchmark','wbar');
wbar2=wbar2.('wbar');
w3=load('all_results_phy3','w');
w3=w3.('w');
wbar3=load('all_results_phy3','wbar');
wbar3=wbar3.('wbar');
w4=load('all_results_phy2','w');
w4=w4.('w');
wbar4=load('all_results_phy2','wbar');
wbar4=wbar4.('wbar');

N11=load('all_results_phy1','N1');
N11=N11.('N1');
N1bar1=load('all_results_phy1','N1bar');
N1bar1=N1bar1.('N1bar');
N12=load('all_results_benchmark','N1');
N12=N12.('N1');
N1bar2=load('all_results_benchmark','N1bar');
N1bar2=N1bar2.('N1bar');
N13=load('all_results_phy3','N1');
N13=N13.('N1');
N1bar3=load('all_results_phy3','N1bar');
N1bar3=N1bar3.('N1bar');
N14=load('all_results_phy2','N1');
N14=N14.('N1');
N1bar4=load('all_results_phy2','N1bar');
N1bar4=N1bar4.('N1bar');

no11=load('all_results_phy1','no1');
no11=no11.('no1');
no1bar1=load('all_results_phy1','no1bar');
no1bar1=no1bar1.('no1bar');
no12=load('all_results_benchmark','no1');
no12=no12.('no1');
no1bar2=load('all_results_benchmark','no1bar');
no1bar2=no1bar2.('no1bar');
no13=load('all_results_phy3','no1');
no13=no13.('no1');
no1bar3=load('all_results_phy3','no1bar');
no1bar3=no1bar3.('no1bar');
no14=load('all_results_phy2','no1');
no14=no14.('no1');
no1bar4=load('all_results_phy2','no1bar');
no1bar4=no1bar4.('no1bar');


N21=load('all_results_phy1','N2');
N21=N21.('N2');
N2bar1=load('all_results_phy1','N2bar');
N2bar1=N2bar1.('N2bar');
N22=load('all_results_benchmark','N2');
N22=N22.('N2');
N2bar2=load('all_results_benchmark','N2bar');
N2bar2=N2bar2.('N2bar');
N23=load('all_results_phy3','N2');
N23=N23.('N2');
N2bar3=load('all_results_phy3','N2bar');
N2bar3=N2bar3.('N2bar');
N24=load('all_results_phy2','N2');
N24=N24.('N2');
N2bar4=load('all_results_phy2','N2bar');
N2bar4=N2bar4.('N2bar');


no21=load('all_results_phy1','no2');
no21=no21.('no2');
no2bar1=load('all_results_phy1','no2bar');
no2bar1=no2bar1.('no2bar');
no22=load('all_results_benchmark','no2');
no22=no22.('no2');
no2bar2=load('all_results_benchmark','no2bar');
no2bar2=no2bar2.('no2bar');
no23=load('all_results_phy1','no2');
no23=no23.('no2');
no2bar3=load('all_results_phy1','no2bar');
no2bar3=no2bar3.('no2bar');
no24=load('all_results_phy2','no2');
no24=no24.('no2');
no2bar4=load('all_results_phy2','no2bar');
no2bar4=no2bar4.('no2bar');


Ne11=load('all_results_phy1','Ne1');
Ne11=Ne11.('Ne1');
Ne1bar1=load('all_results_phy1','Ne1bar');
Ne1bar1=Ne1bar1.('Ne1bar');
Ne12=load('all_results_benchmark','Ne1');
Ne12=Ne12.('Ne1');
Ne1bar2=load('all_results_benchmark','Ne1bar');
Ne1bar2=Ne1bar2.('Ne1bar');
Ne13=load('all_results_phy3','Ne1');
Ne13=Ne13.('Ne1');
Ne1bar3=load('all_results_phy3','Ne1bar');
Ne1bar3=Ne1bar3.('Ne1bar');
Ne14=load('all_results_phy2','Ne1');
Ne14=Ne14.('Ne1');
Ne1bar4=load('all_results_phy2','Ne1bar');
Ne1bar4=Ne1bar4.('Ne1bar');



Ne21=load('all_results_phy1','Ne2');
Ne21=Ne21.('Ne2');
Ne2bar1=load('all_results_phy1','Ne2bar');
Ne2bar1=Ne2bar1.('Ne2bar');
Ne22=load('all_results_benchmark','Ne2');
Ne22=Ne22.('Ne2');
Ne2bar2=load('all_results_benchmark','Ne2bar');
Ne2bar2=Ne2bar2.('Ne2bar');
Ne23=load('all_results_phy3','Ne2');
Ne23=Ne23.('Ne2');
Ne2bar3=load('all_results_phy3','Ne2bar');
Ne2bar3=Ne2bar3.('Ne2bar');
Ne24=load('all_results_phy2','Ne2');
Ne24=Ne24.('Ne2');
Ne2bar4=load('all_results_phy2','Ne2bar');
Ne2bar4=Ne2bar4.('Ne2bar');



zc11=load('all_results_phy1','zc1');
zc11=zc11.('zc1');
zc1bar1=load('all_results_phy1','zc1bar');
zc1bar1=zc1bar1.('zc1bar');
zc12=load('all_results_benchmark','zc1');
zc12=zc12.('zc1');
zc1bar2=load('all_results_benchmark','zc1bar');
zc1bar2=zc1bar2.('zc1bar');
zc13=load('all_results_phy3','zc1');
zc13=zc13.('zc1');
zc1bar3=load('all_results_phy3','zc1bar');
zc1bar3=zc1bar3.('zc1bar');
zc14=load('all_results_phy2','zc1');
zc14=zc14.('zc1');
zc1bar4=load('all_results_phy2','zc1bar');
zc1bar4=zc1bar4.('zc1bar');



zc21=load('all_results_phy1','zc2');
zc21=zc21.('zc2');
zc2bar1=load('all_results_phy1','zc2bar');
zc2bar1=zc2bar1.('zc2bar');
zc22=load('all_results_benchmark','zc2');
zc22=zc22.('zc2');
zc2bar2=load('all_results_benchmark','zc2bar');
zc2bar2=zc2bar2.('zc2bar');
zc23=load('all_results_phy3','zc2');
zc23=zc23.('zc2');
zc2bar3=load('all_results_phy3','zc2bar');
zc2bar3=zc2bar3.('zc2bar');
zc24=load('all_results_phy2','zc2');
zc24=zc24.('zc2');
zc2bar4=load('all_results_phy2','zc2bar');
zc2bar4=zc2bar4.('zc2bar');




ii1=load('all_results_phy1','ii');
ii1=ii1.('ii');
ii2=load('all_results_benchmark','ii');
ii2=ii2.('ii');
ii3=load('all_results_phy3','ii');
ii3=ii3.('ii');
ii4=load('all_results_phy2','ii');
ii4=ii4.('ii');


ss1=load('all_results_phy1','ss');
ss1=ss1.('ss');
ss2=load('all_results_benchmark','ss');
ss2=ss2.('ss');
ss3=load('all_results_phy3','ss');
ss3=ss3.('ss');
ss4=load('all_results_phy2','ss');
ss4=ss4.('ss');


rr1=load('all_results_phy1','rr');
rr1=rr1.('rr');
rr2=load('all_results_benchmark','rr');
rr2=rr2.('rr');
rr3=load('all_results_phy3','rr');
rr3=rr3.('rr');
rr4=load('all_results_phy2','rr');
rr4=rr4.('rr');

dd1=load('all_results','dd');
dd1=dd1.('dd');
dd2=load('all_results_benchmark','dd');
dd2=dd2.('dd');
dd3=load('all_results_benchmark','dd');
dd3=dd3.('dd');
dd4=load('all_results_benchmark','dd');
dd4=dd4.('dd');


%%%%%%%%%% GUIDO %%%%%%%%%%%
pi1=load('all_results_phy1','pi');
pi1=pi1.('pi');
pibar1=load('all_results_phy1','pibar');
pibar1=pibar1.('pibar');
pi2=load('all_results_benchmark','pi');
pi2=pi2.('pi');
pibar2=load('all_results_benchmark','pibar');
pibar2=pibar2.('pibar');
pi3=load('all_results_phy3','pi');
pi3=pi3.('pi');
pibar3=load('all_results_phy3','pibar');
pibar3=pibar3.('pibar');
pi4=load('all_results_phy2','pi');
pi4=pi4.('pi');
pibar4=load('all_results_phy2','pibar');
pibar4=pibar4.('pibar');

R1=load('all_results_phy1','R');
R1=R1.('R');
Rbar1=load('all_results_phy1','Rbar');
Rbar1=Rbar1.('Rbar');
R2=load('all_results_benchmark','R');
R2=R2.('R');
Rbar2=load('all_results_benchmark','Rbar');
Rbar2=Rbar2.('Rbar');
R3=load('all_results_phy3','R');
R3=R3.('R');
Rbar3=load('all_results_phy3','Rbar');
Rbar3=Rbar3.('Rbar');
R4=load('all_results_phy2','R');
R4=R4.('R');
Rbar4=load('all_results_phy2','Rbar');
Rbar4=Rbar4.('Rbar');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




ia=4;
ib=4;
fsize=11;
horz=100;

time=0:1:horz-1;

figure;

subplot(ia,ib,1)
plot(time(1:end-1),0*100*(C12(2:horz)-C1bar2)/C1bar2,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C12(2:horz)-C1bar2)/C1bar2,'g-','LineWidth',2);
%plot(time(1:end-1),0*100*(C11(2:horz)-C1bar1)/C1bar1,'m','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C11(2:horz)-C1bar1)/C1bar1,'r--','LineWidth',2);hold on
plot(time(1:end-1),100*(C13(2:horz)-C1bar3)/C1bar3,'b:','LineWidth',2);hold on
%plot(time(1:end-1),100*(C14(2:horz)-C1bar4)/C1bar4,'y-.','LineWidth',2);hold off
box off;
title('Consumption Social, C(s)','FontSize',fsize);
set(gca,'FontSize',fsize);


subplot(ia,ib,2)
plot(time(1:end-1),0*100*(C1(2:horz)-Cbar1)/Cbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(C2(2:horz)-Cbar2)/Cbar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(C1(2:horz)-Cbar1)/Cbar1,'r--','LineWidth',2);hold on
plot(time(1:end-1),100*(C3(2:horz)-Cbar3)/Cbar3,'b:','LineWidth',2);hold off
box off;
title('Consumption, C','FontSize',fsize);
set(gca,'FontSize',fsize);


subplot(ia,ib,3)
plot(time(1:end-1),0*100*(GDP1(2:horz)-GDPbar1)/GDPbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(GDP2(2:horz)-GDPbar2)/GDPbar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(GDP1(2:horz)-GDPbar1)/GDPbar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(GDP3(2:horz)-GDPbar3)/GDPbar3,'b:','LineWidth',2);hold off
%plot(time(1:end-1),100*(GDP4(2:horz)-GDPbar4)/GDPbar4,'b:','LineWidth',2);hold off
box off;
title('GDP, GDP','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,4)
plot(time(1:end-1),0*100*(w1(2:horz)-wbar1)/wbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(w2(2:horz)-wbar2)/wbar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(w1(2:horz)-wbar1)/wbar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(w3(2:horz)-wbar3)/wbar3,'b:','LineWidth',2);hold off
box off;
title('Wage, w','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,5)
plot(time(1:end-1),0*100*(no11(2:horz)-no1bar1)/no1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no12(2:horz)-no1bar2)/no1bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(no11(2:horz)-no1bar1)/no1bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no13(2:horz)-no1bar3)/no1bar3,'b:','LineWidth',2);hold off
box off;
title('Operative Social, No(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,6)
plot(time(1:end-1),0*100*(N11(2:horz)-N1bar1)/N1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N12(2:horz)-N1bar2)/N1bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(N11(2:horz)-N1bar1)/N1bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N13(2:horz)-N1bar3)/N1bar3,'b:','LineWidth',2);hold off
box off;
title('Firms Social, N(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,7)
plot(time(1:end-1),0*100*(Ne11(2:horz)-Ne1bar1)/Ne1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne12(2:horz)-Ne1bar2)/Ne1bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(Ne11(2:horz)-Ne1bar1)/Ne1bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne13(2:horz)-Ne1bar3)/Ne1bar3,'b:','LineWidth',2);hold off
box off;
title('Entrants Social, Ne(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,8)
plot(time(1:end-1),0*100*(zc11(2:horz)-zc1bar1)/zc1bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc12(2:horz)-zc1bar2)/zc1bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(zc11(2:horz)-zc1bar1)/zc1bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc13(2:horz)-zc1bar3)/zc1bar3,'b:','LineWidth',2);hold off
box off;
title('Cut-off Social, zc(s)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,9)
plot(time(1:end-1),0*100*(no21(2:horz)-no2bar1)/no2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no22(2:horz)-no2bar2)/no2bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(no21(2:horz)-no2bar1)/no2bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(no23(2:horz)-no2bar3)/no2bar3,'b:','LineWidth',2);hold off
box off;
title('Operative Non-Social, No(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,10)
plot(time(1:end-1),0*100*(N21(2:horz)-N2bar1)/N2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N22(2:horz)-N2bar2)/N2bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(N21(2:horz)-N2bar1)/N2bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(N23(2:horz)-N2bar3)/N2bar3,'b:','LineWidth',2);hold off
box off;
title('Firms Non-Social, N(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,11)
plot(time(1:end-1),0*100*(Ne21(2:horz)-Ne2bar1)/Ne2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne22(2:horz)-Ne2bar2)/Ne2bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(Ne21(2:horz)-Ne2bar1)/Ne2bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(Ne23(2:horz)-Ne2bar3)/Ne2bar3,'b:','LineWidth',2);hold off
box off;
title('Entrants Non-Social, Ne(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,12)
plot(time(1:end-1),0*100*(zc21(2:horz)-zc2bar1)/zc2bar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc22(2:horz)-zc2bar2)/zc2bar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(zc21(2:horz)-zc2bar1)/zc2bar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(zc23(2:horz)-zc2bar3)/zc2bar3,'b:','LineWidth',2);hold off
box off;
title('Cut-off Non-Social, zc(ns)','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,13)
plot(time,328000000*ii2(1:horz),'g-','LineWidth',2);hold on
plot(time,328000000*ii1(1:horz),'r--','LineWidth',2);hold on
plot(time,328000000*ii3(1:horz),'b:','LineWidth',2);hold off
box off;
title('Infected, ii','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,14)
plot(time,328000000*ss2(1:horz),'g-','LineWidth',2);hold on
plot(time,328000000*ss1(1:horz),'r--','LineWidth',2);hold on
plot(time,328000000*ss3(1:horz),'b:','LineWidth',2);hold off
box off;
title('Susceptibles, ss','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,15)
plot(time,328000000*rr2(1:horz),'g-','LineWidth',2);hold on
plot(time,328000000*rr1(1:horz),'r--','LineWidth',2);hold on
plot(time,328000000*rr3(1:horz),'b:','LineWidth',2);hold off
box off;
title('Recovered, rr','FontSize',fsize);
set(gca,'FontSize',fsize);

subplot(ia,ib,16)
plot(time,328000000*dd2(1:horz),'g-','LineWidth',2);hold on
plot(time,328000000*dd1(1:horz),'r--','LineWidth',2);hold on
plot(time,328000000*dd3(1:horz),'b:','LineWidth',2);hold off
box off;
title('Deaths, dd','FontSize',fsize);
xlabel('Weeks','FontSize',fsize);
set(gca,'FontSize',fsize);
legend('Benchmark','\vartheta_{y} = 1', '\vartheta_{y} = 2')

%%%%%%%%%%% GUIDO  %%%%%%%%%%

figure(2);
subplot(3,1,1)
plot(time(1:end-1),0*100*(pi1(2:horz)-pibar1)/pibar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(pi2(2:horz)-pibar2)/pibar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(pi1(2:horz)-pibar1)/pibar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(pi3(2:horz)-pibar3)/pibar3,'b:','LineWidth',2);hold off
box off;
title('Inflation','FontSize',fsize);
set(gca,'FontSize',fsize);


subplot(3,1,2)
plot(time(1:end-1),0*100*(R1(2:horz)-Rbar1)/Rbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-1),100*(R2(2:horz)-Rbar2)/Rbar2,'g-','LineWidth',2);hold on
plot(time(1:end-1),100*(R1(2:horz)-Rbar1)/Rbar1,'r--','LineWidth',1.5);hold on
plot(time(1:end-1),100*(R3(2:horz)-Rbar3)/Rbar3,'b:','LineWidth',2);hold off
box off;
title('Nominal Int Rate','FontSize',fsize);
set(gca,'FontSize',fsize);



%time1=time(1,1:(end-1));
realrate1=1+R1(1:(horz-1))-pi1(2:horz);
realrate2=1+R2(1:(horz-1))-pi2(2:horz);
realrate3=1+R3(1:(horz-1))-pi3(2:horz);
realrate4=1+R4(1:(horz-1))-pi4(2:horz);


subplot(3,1,3)
plot(time(1:end-2),0*100*(realrate1(2:horz-1)-Rbar1)/Rbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-2),100*(realrate2(2:horz-1)-Rbar2)/Rbar2,'g-','LineWidth',2);hold on
plot(time(1:end-2),100*(realrate1(2:horz-1)-Rbar1)/Rbar1,'m:','LineWidth',1.5);hold on
plot(time(1:end-2),100*(realrate3(2:horz-1)-Rbar3)/Rbar3,'r-','LineWidth',2);hold off
box off;
title('Real Int Rate','FontSize',fsize);
set(gca,'FontSize',fsize);

legend('','Benchmark','\vartheta_{y} = 1', '\vartheta_{y} = 2')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

return

subtitle('Figure 1: Simulation Results Benchmark vs Flexible');
orient landscape
print -dpdf -fillpage fig_bench_vs_flex_noC2