%%%%%%%%%%%% ACS (2021). How to replicate paper Figures 6

%%%%%%%%%%%% 1) Run acs_benchmark on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results and simulate benchmark response.

%%%%%%%%%%%% 2) It can be run multiple times to generate all_results_phyx, 
%%%%%%%%%%%% by changing the parameter of the Taylor Rule, as explained in 
%%%%%%%%%%%% plot_all_phys (some are already stored for semplicity).

%%%%%%%%%%%% 3) Run plot_all_phys for figure 6 in the paper.
