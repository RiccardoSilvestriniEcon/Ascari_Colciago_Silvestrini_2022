%%%%%%%%%%%% How to replicate paper:

%%%%%%%%%%%% 1) Run SS_025/075 to store steady states of the two different
%%%%%%%%%%%% economies.

%%%%%%%%%%%% 2) Run acs_..._025/075 on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result/_L, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results for models with different size of social sector.

%%%%%%%%%%%% 3) Run plot_paper for figure 8 in the paper.
