%%%%%%%%%%%%%%%%% How to replicate paper:

%%%%%%%%%%%% 1) Run SS_banchmark to store steady state of the economy

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results and simulate model

%%%%%%%%%%%% 3) Run acs_..._25/50/permanent on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result_L/2/3, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results for different duration of SD measures

%%%%%%%%%%%% 4) Run plot_paper for figure 7 in the paper
