%%%%%%%%%%%%%%%%% How to replicate paper:

%%%%%%%%%%%% 1) Run SS_banchmark to store steady state of the economy

%%%%%%%%%%%% 2) Run acs_benchmark on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results

%%%%%%%%%%%% 2) Run acs_flex on dynare 4.4.3 (use plotter in
%%%%%%%%%%%% plot_agg_result_L, go_calibrate and calibrate_pi) to store
%%%%%%%%%%%% results

%%%%%%%%%%%% 4) Run plot_paper figure in the paper
